package com.example.scrolmenu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class sec extends AppCompatActivity {


    private String coffeeType1="";
    private String coffeeType2="";
    private String coffeeType3="";
    private String coffeeType4="";
    private String coffeeType5="";
    private String coffeeType6="";
    private String coffeeType7="";
    private String coffeeType8="";
    private String coffeeType9="";
    private String coffeeType10="";

    private String sweetType1="";
    private String sweetType2="";
    private String sweetType3="";
    private String sweetType4="";

    private Button mkOrder;
    int i;


    private int numCofe1 = 1;
    private int numCofe2 = 1;
    private int numCofe3 = 1;
    private int numCofe4 = 1;
    private int numCofe5 = 1;
    private int numCofe6 = 1;
    private int numCofe7 = 1;
    private int numCofe8 = 1;
    private int numCofe9 = 1;
    private int numCofe10 = 1;
    private int numCofe11 = 1;
    private int numCofe12 = 1;
    private int numCofe13 = 1;
    private int numCofe14 = 1;

    TextView tx1;
    TextView tx2;
    TextView tx3;
    TextView tx4;
    TextView tx5;
    TextView tx6;
    TextView tx7;
    TextView tx8;
    TextView tx9;
    TextView tx10;
    TextView tx11;
    TextView tx12;
    TextView tx13;
    TextView tx14;


    TextView txtv1;
    TextView txtv2;
    TextView txtv3;
    TextView txtv4;
    TextView txtv5;
    TextView txtv6;
    TextView txtv7;
    TextView txtv8;
    TextView txtv9;
    TextView txtv10;
    TextView txtv11;
    TextView txtv12;
    TextView txtv13;
    TextView txtv14;

    CheckBox cb1;
    CheckBox cb2;
    CheckBox cb3;
    CheckBox cb4;
    CheckBox cb5;
    CheckBox cb6;
    CheckBox cb7;
    CheckBox cb8;
    CheckBox cb9;
    CheckBox cb10;
    CheckBox cb11;
    CheckBox cb12;
    CheckBox cb13;
    CheckBox cb14;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec);

        mkOrder = (Button) findViewById(R.id.button2);

        tx1 = (TextView) findViewById(R.id.carMacciatoP);
        tx2 = (TextView) findViewById(R.id.amrcP);
        tx3 = (TextView) findViewById(R.id.mochaP);
        tx4 = (TextView) findViewById(R.id.latteP);
        tx5 = (TextView) findViewById(R.id.esprsoP);
        tx6 = (TextView) findViewById(R.id.CappuccinoP);
        tx7 = (TextView) findViewById(R.id.frenchP);
        tx8 = (TextView) findViewById(R.id.chocoMochaP);
        tx9 = (TextView) findViewById(R.id.spanishP);
        tx10 = (TextView) findViewById(R.id.icedCrmlMacchiatoP);
        tx11 = (TextView) findViewById(R.id.BrowniesP);
        tx12 = (TextView) findViewById(R.id.MacaroonsP);
        tx13 = (TextView) findViewById(R.id.CookiesP);
        tx14 = (TextView) findViewById(R.id.CupcakesP);

        txtv1 = (TextView) findViewById(R.id.counter1);
        txtv2 = (TextView) findViewById(R.id.counter2);
        txtv3 = (TextView) findViewById(R.id.counter3);
        txtv4 = (TextView) findViewById(R.id.counter4);
        txtv5 = (TextView) findViewById(R.id.counter5);
        txtv6 = (TextView) findViewById(R.id.counter6);
        txtv7 = (TextView) findViewById(R.id.counter7);
        txtv8 = (TextView) findViewById(R.id.counter8);
        txtv9 = (TextView) findViewById(R.id.counter9);
        txtv10 = (TextView) findViewById(R.id.counter10);
        txtv11 = (TextView) findViewById(R.id.counter11);
        txtv12 = (TextView) findViewById(R.id.counter12);
        txtv13 = (TextView) findViewById(R.id.counter13);
        txtv14 = (TextView) findViewById(R.id.counter14);

        cb1= (CheckBox) findViewById(R.id.crmlMachiatoBtn);
        cb2= (CheckBox) findViewById(R.id.amrcanoBtn);
        cb3= (CheckBox) findViewById(R.id.mochaBtn);
        cb4= (CheckBox) findViewById(R.id.latteBtn);
        cb5= (CheckBox) findViewById(R.id.esprsoBtn);
        cb6= (CheckBox) findViewById(R.id.CappuccinoBtn);
        cb7= (CheckBox) findViewById(R.id.frenchBtn);
        cb8= (CheckBox) findViewById(R.id.chocoMochaBtn);
        cb9= (CheckBox) findViewById(R.id.spanishBtn);
        cb10=(CheckBox) findViewById(R.id.icedCrmlMacchiatoBtn);
        cb11=(CheckBox) findViewById(R.id.browniBtn);
        cb12=(CheckBox) findViewById(R.id.MacaroonsBtn);
        cb13=(CheckBox) findViewById(R.id.CookiesBtn);
        cb14=(CheckBox) findViewById(R.id.CupcakesBtn);


        mkOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(sec.this, basket.class);

                String order = coffeeType1 + coffeeType2 + coffeeType3 +coffeeType4
                             + coffeeType5 + coffeeType6 + coffeeType7 + coffeeType8
                             + coffeeType9 + coffeeType10 + sweetType1 + sweetType2
                             + sweetType3 + sweetType4 ;
                //add data to intent
                i.putExtra("order", order);
                startActivity(i);


                finish();

            }

        });
    }

    public void selectCoffee(View view) {

        switch (view.getId()) {
            case R.id.crmlMachiatoBtn:
                if(cb1.isChecked()){
                    coffeeType1 = "Hot Caramel Macchiato \n";
                    break;}
                else coffeeType1="";
            case R.id.amrcanoBtn:
                if(cb2.isChecked()){
                    coffeeType2 = "Hot Amricano \n";
                    break;}
                else coffeeType2="";
            case R.id.mochaBtn:
                if(cb3.isChecked()){
                    coffeeType3 = "Hot Mocha \n";
                    break;}
                else coffeeType3="";
            case R.id.latteBtn:
                if(cb4.isChecked()){
                    coffeeType4 = "Hot Latte \n";
                    break;}
                else coffeeType4="";
            case R.id.esprsoBtn:
                if(cb5.isChecked()){
                    coffeeType5 = "Hot Espresso \n";
                    break;}
                else coffeeType5="";
            case R.id.CappuccinoBtn:
                if(cb6.isChecked()){
                    coffeeType6 = "Hot Cappuccino \n";
                    break;}
                else coffeeType6="";

            case R.id.frenchBtn:
                if(cb7.isChecked()){
                    coffeeType7 = "Iced French Vanilla \n";
                    break;}
                    else coffeeType7="";
            case R.id.chocoMochaBtn:
                if(cb8.isChecked()){
                    coffeeType8 = "Iced Chocolate Mohca \n";
                    break;}
                else coffeeType8="";
            case R.id.spanishBtn:
                if(cb9.isChecked()){
                    coffeeType9 = "Iced Spanish Latte \n";
                    break;}
                else coffeeType9="";
            case R.id.icedCrmlMacchiatoBtn:
                if(cb10.isChecked()) {
                    coffeeType10 = "Iced Caramel Macchiato \n";
                }
                else coffeeType10="";

        }
    }

    public void selectSweets(View v) {

        switch (v.getId()) {
            case R.id.browniBtn:
                if(cb11.isChecked()){
                    sweetType1 = "Brownies \n";
                    break;}
                    else  sweetType1="";
            case R.id.MacaroonsBtn:
                if(cb12.isChecked()){
                    sweetType2 = "Macaroons \n";
                    break;}
                else  sweetType2="";

            case R.id.CookiesBtn:
                if(cb13.isChecked()){
                    sweetType3 = "Cookies \n";
                    break;}
                else  sweetType3="";

            case R.id.CupcakesBtn:
                if(cb14.isChecked()) {
                    sweetType4 = "Cupcakes \n";
                } else  sweetType4="";
        }
    }

    public void increment(View v) {

        switch (v.getId()) {
            case R.id.incBtn1:
                numCofe1 += 1;
                i = numCofe1*10;
                tx1.setText("" +i +" SR");
                txtv1.setText("" + numCofe1);
                break;
            case R.id.incBtn2:
                numCofe2 += 1;
                i = numCofe2*8;
                tx2.setText("" +i +" SR");
                txtv2.setText("" + numCofe2);
                break;
            case R.id.incBtn3:
                numCofe3 += 1;
                i = numCofe3*12;
                tx3.setText("" +i +" SR");
                txtv3.setText("" + numCofe3);
                break;
            case R.id.incBtn4:
                numCofe4 += 1;
                i = numCofe4*10;
                tx4.setText("" +i +" SR");
                txtv4.setText("" + numCofe4);
                break;
            case R.id.incBtn5:
                numCofe5 += 1;
                i = numCofe5*7;
                tx5.setText("" +i +" SR");
                txtv5.setText("" + numCofe5);
                break;
            case R.id.incBtn6:
                numCofe6 += 1;
                i = numCofe6*12;
                tx6.setText("" +i +" SR");
                txtv6.setText("" + numCofe6);
                break;
            case R.id.incBtn7:
                numCofe7 += 1;
                i = numCofe7*12;
                tx7.setText("" +i +" SR");
                txtv7.setText("" + numCofe7);
                break;
            case R.id.incBtn8:
                numCofe8 += 1;
                i = numCofe8*10;
                tx8.setText("" +i +" SR");
                txtv8.setText("" + numCofe8);
                break;
            case R.id.incBtn9:
                numCofe9 += 1;
                i = numCofe9*10;
                tx9.setText("" +i +" SR");
                txtv9.setText("" + numCofe9);
                break;
            case R.id.incBtn10:
                numCofe10 += 1;
                i = numCofe10*14;
                tx10.setText("" +i +" SR");
                txtv10.setText("" + numCofe10);
                break;
            case R.id.incBtn11:
                numCofe11 += 1;
                i = numCofe11*5;
                tx11.setText("" +i +" SR");
                txtv11.setText("" + numCofe11);
                break;
            case R.id.incBtn12:
                numCofe12 += 1;
                i = numCofe12*6;
                tx12.setText("" +i +" SR");
                txtv12.setText("" + numCofe12);
                break;
            case R.id.incBtn13:
                numCofe13 += 1;
                i = numCofe13*4;
                tx13.setText("" +i +" SR");
                txtv13.setText("" + numCofe13);
                break;
            case R.id.incBtn14:
                numCofe14 += 1;
                i = numCofe14*4;
                tx14.setText("" +i +" SR");
                txtv14.setText("" + numCofe14);

        }
    }

    public void decrement(View v) {

        if(v.getId()==R.id.decBtn1){
            if (numCofe1 > 1) {
                numCofe1 -= 1;
                i = numCofe1*10;
                tx1.setText("" +i +" SR");
                txtv1.setText("" + numCofe1);

            }  else{
                txtv1.setText("" + numCofe1);
            }}

        if (v.getId()==R.id.decBtn2){
            if (numCofe2 > 1) {
                numCofe2 -= 1;
                i = numCofe2*8;
                tx2.setText("" +i +" SR");
                txtv2.setText("" + numCofe2);

            }  else{
                txtv2.setText("" + numCofe2);
            }}

        if (v.getId()==R.id.decBtn3){
            if (numCofe3 > 1) {
                numCofe3 -= 1;
                i = numCofe3*12;
                tx3.setText("" +i +" SR");
                txtv3.setText("" + numCofe3);

            }  else{
                txtv3.setText("" + numCofe3);
            }}

        if (v.getId()==R.id.decBtn4){
            if (numCofe4 > 1) {
                numCofe4 -= 1;
                i = numCofe4*10;
                tx4.setText("" +i +" SR");
                txtv4.setText("" + numCofe4);

            }  else{
                txtv4.setText("" + numCofe4);
            }}

        if (v.getId()==R.id.decBtn5){
            if (numCofe5 > 1) {
                numCofe5 -= 1;
                i = numCofe5*7;
                tx5.setText("" +i +" SR");
                txtv5.setText("" + numCofe5);

            }  else{
                txtv5.setText("" + numCofe5);
            }}

        if (v.getId()==R.id.decBtn6){
            if (numCofe6 > 1) {
                numCofe6 -= 1;
                i = numCofe6*12;
                tx6.setText("" +i +" SR");
                txtv6.setText("" + numCofe6);

            }  else{
                txtv6.setText("" + numCofe6);
            }}

        if (v.getId()==R.id.decBtn7){
            if (numCofe7 > 1) {
                numCofe7 -= 1;
                i = numCofe7*12;
                tx7.setText("" +i +" SR");
                txtv7.setText("" + numCofe7);

            }  else{
                txtv7.setText("" + numCofe7);
            }}

        if (v.getId()==R.id.decBtn8){
            if (numCofe8 > 1) {
                numCofe8 -= 1;
                i = numCofe8*10;
                tx8.setText("" +i +" SR");
                txtv8.setText("" + numCofe8);

            }  else{
                txtv8.setText("" + numCofe8);
            }}

        if (v.getId()==R.id.decBtn9){
            if (numCofe9 > 1) {
                numCofe9 -= 1;
                i = numCofe9*10;
                tx9.setText("" +i +" SR");
                txtv9.setText("" + numCofe9);

            }  else{
                txtv9.setText("" + numCofe9);
            }}

        if (v.getId()==R.id.decBtn10){
            if (numCofe10 > 1) {
                numCofe10 -= 1;
                i = numCofe10*14;
                tx10.setText("" +i +" SR");
                txtv10.setText("" + numCofe10);

            }  else{
                txtv10.setText("" + numCofe10);
            }}

        if (v.getId()==R.id.decBtn11){
            if (numCofe11 > 1) {
                numCofe11 -= 1;
                i = numCofe11*5;
                tx11.setText("" +i +" SR");
                txtv11.setText("" + numCofe11);

            }  else{
                txtv11.setText("" + numCofe11);
            }}
        if (v.getId()==R.id.decBtn12){
            if (numCofe12 > 1) {
                numCofe12 -= 1;
                i = numCofe12*6;
                tx12.setText("" +i +" SR");
                txtv12.setText("" + numCofe12);

            }  else{
                txtv12.setText("" + numCofe12);
            }}

        if (v.getId()==R.id.decBtn13){
            if (numCofe13 > 1) {
                numCofe13 -= 1;
                i = numCofe13*4;
                tx13.setText("" +i +" SR");
                txtv13.setText("" + numCofe13);

            }  else{
                txtv13.setText("" + numCofe13);
            }}

        if (v.getId()==R.id.decBtn14){
            if (numCofe14 > 1) {
                numCofe14 -= 1;
                i = numCofe14*4;
                tx14.setText("" +i +" SR");
                txtv14.setText("" + numCofe14);

            }  else{
                txtv14.setText("" + numCofe14);
            }}

    }

    public void back(View v){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}



